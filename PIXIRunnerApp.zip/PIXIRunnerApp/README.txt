Assets: 
	Game1:
		Images:
			character assets: https://craftpix.net/freebies/free-pixel-art-tiny-hero-sprites/ creator: CRAFTPIX.NET
			
			world assets: https://www.gamedevmarket.net/asset/medieval-pixel-art-asset-free/ creator: blackspirestudio https://www.gamedevmarket.net/member/blackspirestudio/

			enemy assets:
				wizard: https://lionheart963.itch.io/wizard?download creator: Warren Clark https://lionheart963.itch.io/
				reaper-man: https://craftpix.net/freebies/free-reaper-man-chibi-2d-game-sprites/ creator: CRAFTPIX.NET
		Code:
			https://stackoverflow.com/questions/30678438/matter-js-sprite-size
			https://stackoverflow.com/questions/22686917/matter-js-change-colors/54617580
			https://brm.io/matter-js/docs/
			https://github.com/liabru/matter-js/issues/104
			https://www.geeksforgeeks.org/creating-range-slider-html-using-javascript/

		Sounds:
			https://freesound.org/people/bradwesson/sounds/135936/
			https://freesound.org/people/SoundCollectah/sounds/157804/
			https://freesound.org/people/denao270/sounds/346373/
			https://downloads.khinsider.com/game-soundtracks/album/remixed-pixel-dungeon-android-game-music @watawatabou twitter
			https://freesound.org/people/FxKid2/sounds/365810/
			https://freesound.org/people/Reitanna/sounds/344033/