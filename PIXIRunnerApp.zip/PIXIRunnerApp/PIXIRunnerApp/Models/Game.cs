﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace PIXIRunnerApp.Models
{
    public class Game
    {
        public int gameID { get; set; }

        public string name { get; set; }

        public string discription { get; set; }
    }
}
